package com.example.cuizonn_mvvm

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class UserViewModel : ViewModel() {
    private val _users = MutableStateFlow<List<User>>(emptyList())
    val users: StateFlow<List<User>> = _users

    init {
        _users.value = listOf(
            User("Russel Ebanez", "russel.ebanez@hcdc.edu.ph", "09688184444", "https://i.pravatar.cc/150?u=1"),
            User("Matt Francis Placer", "matt.placer@hcdc.edu.ph", "09245875632", "https://i.pravatar.cc/150?u=2"),
            User("Lorenzo Penarubia", "lorenzo.penarubia@hcdc.edu.ph", "09874625784", "https://i.pravatar.cc/150?u=3"),
            User("Christan Cuizon", "christan.cuizon@hcdc.edu.ph", "09684920288", "https://i.pravatar.cc/150?u=4"),
            User("Ernkris Jhon Laid", "ernkris.jhon.laid@hcdc.edu.ph", "09786215432", "https://i.pravatar.cc/150?u=5"),
            User("Kent Abasolo", "kent.abasolo@hcdc.edu.ph", "094536920488", "https://i.pravatar.cc/150?u=6"),
            User("Sherwin Awa", "sherwin.awa@hcdc.edu.ph", "09456872344", "https://i.pravatar.cc/150?u=7")
        )
    }
}