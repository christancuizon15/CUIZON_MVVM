package com.example.cuizonn_mvvm

data class User(
    val name: String,
    val email: String,
    val phone: String,
    val imageUrl: String
)